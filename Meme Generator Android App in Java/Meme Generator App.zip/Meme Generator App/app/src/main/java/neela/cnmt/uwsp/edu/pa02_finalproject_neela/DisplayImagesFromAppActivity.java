package neela.cnmt.uwsp.edu.pa02_finalproject_neela;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.Toolbar;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

/**
 * A simple launcher activity containing a summary sample description, sample log and a custom
 * {@link androidx.fragment.app.Fragment} which can display a view.
 * <p>
 * For devices with displays with a width of 720dp or greater, the sample log is always visible,
 * on other devices it's visibility is controlled by an item on the Action Bar.
 */
public class DisplayImagesFromAppActivity extends SampleActivityBase implements CustomAdapter.OnMemeImageListener {

    Fragment fragment;
    protected static Drawable[] mDrawable;

    @Override
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        this.fragment = fragment;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_images_from_app);
        setActionBar((Toolbar) findViewById(R.id.my_toolbar));

        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            RecyclerViewFragment fragment = new RecyclerViewFragment();
            transaction.replace(R.id.sample_content_fragment, fragment);
            transaction.commit();
        }
    }

    @Override
    public void onMemeImageClick(int position) {
    }
}

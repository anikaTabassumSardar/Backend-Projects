package neela.cnmt.uwsp.edu.pa02_finalproject_neela;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private static final int MY_PERMISSION_REQUEST = 1;
    private static final int RESULT_IMPORT_IMAGE_DEVICE = 2;
    private static final int RESULT_IMPORT_IMAGE_APP = 3;

    private Button importButton, saveButton, shareButton, applyChangesButton;
    private TextView textViewTop, textViewBottom;
    private EditText editTextTop, editTextBottom;
    protected static ImageView memeImageView;
    private CheckBox checkBox;

    private String currentImage = "";
    private Uri uriToImageToShare;

    protected static Drawable[] mDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)){
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE }, MY_PERMISSION_REQUEST);
            }else{
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE }, MY_PERMISSION_REQUEST);
            }
        }else{
            //do nothing
        }

        memeImageView = (ImageView) findViewById(R.id.memeImageView);

        textViewTop = (TextView) findViewById(R.id.textViewTop);
        textViewBottom = (TextView) findViewById(R.id.textViewBottom);

        editTextTop = (EditText) findViewById(R.id.editTextTop);
        editTextBottom = (EditText) findViewById(R.id.editTextBottom);

        applyChangesButton = (Button) findViewById(R.id.applyChanges);

        importButton = (Button) findViewById(R.id.importImage);
        saveButton = (Button) findViewById(R.id.save);
        shareButton = (Button) findViewById(R.id.share);

        checkBox = (CheckBox) findViewById(R.id.checkBox);

        //disable buttons unless the meme is ready
        // to be saved and shared
        saveButton.setEnabled(false);
        shareButton.setEnabled(false);

        applyChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textViewTop.setText(editTextTop.getText().toString());
                textViewBottom.setText(editTextBottom.getText().toString());

                editTextTop.setText("");
                editTextBottom.setText("");
            }
        });

        importButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImportMenu(v);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View content = findViewById(R.id.centerLayout);
                Bitmap bitmap = getScreenShot(content);
                currentImage = "meme" + System.currentTimeMillis() + ".png";
                store(bitmap, currentImage);
                shareButton.setEnabled(true);
            }
        });

        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareImage();
            }
        });

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Is the view now checked?
                boolean checked = ((CheckBox) v).isChecked();
                if(checked){
                    textViewBottom.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.colorBlack));
                    textViewTop.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.colorBlack));
                }
                else{
                    textViewBottom.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.colorWhite));
                    textViewTop.setTextColor(ContextCompat.getColor(MainActivity.this, R.color.colorWhite));
                }
            }
        });
    }

    public static Bitmap getScreenShot(View view){
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return bitmap;
    }

    public void store(Bitmap bitmap, String fileName){
        String dirPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/MEME";

        File dir = new File(dirPath);
        if(!dir.exists()){
            dir.mkdir();
        }
        File file = new File(dirPath, fileName);

        try{
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();

            MediaScannerConnection.scanFile(this,
                    new String[] { file.toString() }, null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                            Log.i("ExternalStorage", "Scanned " + path + ":");
                            Log.i("ExternalStorage", "-> uri=" + uri);
                            uriToImageToShare = uri;
                        }
                    });
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
        }catch(Exception e){
            Toast.makeText(this, "Error while saving!", Toast.LENGTH_SHORT).show();
        }

    }

    private void shareImage(){
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        shareIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        shareIntent.putExtra(Intent.EXTRA_STREAM, uriToImageToShare);
        shareIntent.setType("image/png");
        try{
            startActivity(Intent.createChooser(shareIntent, getResources().getText(R.string.share_via)));
        }catch(ActivityNotFoundException e) {
            Toast.makeText(this, "No sharing app found!", Toast.LENGTH_SHORT).show();
        }
    }

    public void showImportMenu(View v){
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.import_menu);
        popupMenu.show();

    }

    public void showImportFromDevice(){
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, RESULT_IMPORT_IMAGE_DEVICE);
    }

    public void showImportFromApp(View v){
        Intent intent = new Intent(MainActivity.this, DisplayImagesFromAppActivity.class);
        startActivityForResult(intent, RESULT_IMPORT_IMAGE_APP);
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()){
            case R.id.device:
                showImportFromDevice();
                return true;
            case R.id.app:
                showImportFromApp(importButton);
                return true;
            default:
                Toast.makeText(this, "No import menu item was selected!", Toast.LENGTH_SHORT).show();
                return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode == RESULT_IMPORT_IMAGE_DEVICE && resultCode == RESULT_OK && data != null){
            Uri importedImage = data.getData();
            try {
                memeImageView.setImageBitmap(BitmapFactory.decodeStream(getContentResolver().openInputStream(importedImage)));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            saveButton.setEnabled(true);
            shareButton.setEnabled(false);
        }
        else if(Integer.parseInt(data.getStringExtra("requestCode"))== RESULT_IMPORT_IMAGE_APP&& resultCode == RESULT_OK && data != null){
            int position = Integer.parseInt(data.getStringExtra("position"));
            memeImageView.setImageDrawable(mDrawable[position]);
            saveButton.setEnabled(true);
            shareButton.setEnabled(false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case MY_PERMISSION_REQUEST: {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                        //do nothing
                    }else{
                        Toast.makeText(this, "No permission granted", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    return;
                }
            }
        }
    }

}

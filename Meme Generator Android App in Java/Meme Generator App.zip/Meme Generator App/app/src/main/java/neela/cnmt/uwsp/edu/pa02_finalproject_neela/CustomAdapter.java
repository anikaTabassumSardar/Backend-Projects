package neela.cnmt.uwsp.edu.pa02_finalproject_neela;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import static android.app.Activity.RESULT_OK;

/**
 * Provide views to RecyclerView with data from mDataSet.
 */
public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {
    private Drawable[] mDataSet;
    private OnMemeImageListener onMemeImageListener;
    private DisplayImagesFromAppActivity mContext;
    private static final int RESULT_IMPORT_IMAGE_APP = 3;

    // BEGIN_INCLUDE(recyclerViewSampleViewHolder)
    /**
     * Provide a reference to the type of views that you are using (custom ViewHolder)
     */
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final ImageView imageView;
        private OnMemeImageListener onMemeImageListener;

        public ViewHolder(View v, OnMemeImageListener onMemeImageListener) {
            super(v);
            this.onMemeImageListener = onMemeImageListener;
            itemView.setOnClickListener(this);
            imageView = (ImageView) v.findViewById(R.id.imageViewTemplate);

        }

        public ImageView getImageView() {
            return imageView;
        }

        @Override
        public void onClick(View v) {
            onMemeImageListener.onMemeImageClick(getAdapterPosition());
        }
    }
    // END_INCLUDE(recyclerViewSampleViewHolder)

    /**
     * Initialize the dataset of the Adapter.
     *
     * @param dataSet String[] containing the data to populate views to be used by RecyclerView.
     */
    public CustomAdapter(Drawable[] dataSet, OnMemeImageListener onMemeImageListener, DisplayImagesFromAppActivity mContext) {
        mDataSet = dataSet;
        this.onMemeImageListener = onMemeImageListener;
        this.mContext = mContext;
    }

    // BEGIN_INCLUDE(recyclerViewOnCreateViewHolder)
    // Create new views (invoked by the layout manager)
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.text_row_item, viewGroup, false);
        return new ViewHolder(v, onMemeImageListener);
    }
    // END_INCLUDE(recyclerViewOnCreateViewHolder)

    // BEGIN_INCLUDE(recyclerViewOnBindViewHolder)
    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.getImageView().setImageDrawable(mDataSet[position]);
        viewHolder.getImageView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, MainActivity.class);
                intent.putExtra("position", Integer.toString(position));
                intent.putExtra("requestCode", Integer.toString(RESULT_IMPORT_IMAGE_APP));
                mContext.setResult(RESULT_OK, intent);
                mContext.finish();
            }
        });

    }
    // END_INCLUDE(recyclerViewOnBindViewHolder)

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataSet.length;
    }

    /**
     * Interface to keep track of the onclicks for the images in grid view
     */
    public interface OnMemeImageListener{
        void onMemeImageClick(int position);
    }
}
